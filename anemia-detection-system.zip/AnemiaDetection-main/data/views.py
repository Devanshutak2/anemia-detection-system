from django.shortcuts import render
from . models import Allimage

# Create your views here.
def index(r):
    return render(r, 'imgFormat.html')

def collect(r):
    if r.method == "POST":
        usrName = r.POST['username']
        img_data = r.POST['img1']  # Replace 'img_data' with the actual name of your form field

        # Create a new instance of the Allimage model
        allimage_instance = Allimage(usrName=usrName)
        
        # Save the image data to the model instance
        allimage_instance.save_image_from_data(img_data)

        # Save the model instance
        allimage_instance.save()
    
    return render(r, "image_collection.html")