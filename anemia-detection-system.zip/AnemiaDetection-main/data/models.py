from django.db import models
import base64
from django.core.files.base import ContentFile

# Create your models here.
class Allimage(models.Model):
    usrName = models.CharField(max_length=200)
    nails = models.ImageField(upload_to="data/nails", null=True)
    palm = models.ImageField(upload_to="data/palm", null=True)
    hand = models.ImageField(upload_to="data/hand", null=True)
    eyes = models.ImageField(upload_to="data/eyes", null=True)

    def save_image_from_data(self, data, imgtype='nails'):
        # Decode the base64 image data
        format, imgstr = data.split(';base64,')
        ext = format.split('/')[-1]
        img_data = ContentFile(base64.b64decode(imgstr), name=f"{self.usrName}.{ext}")

        # Save the image to the model field
        if imgtype == "nails":
            self.nails.save(f"{self.usrName}.{ext}", img_data, save=True)
        elif imgtype == "palm":
            self.palm.save(f"{self.usrName}.{ext}", img_data, save=True)
        elif imgtype == "hand":
            self.hand.save(f"{self.usrName}.{ext}", img_data, save=True)
        elif imgtype == "eyes":
            self.eyes.save(f"{self.usrName}.{ext}", img_data, save=True)

    def __str__(self) -> str:
        return self.usrName