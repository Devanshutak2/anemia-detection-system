from django.urls import path
from . import views

urlpatterns = [
    path('page/', views.index),
    path('collect/', views.collect),
]